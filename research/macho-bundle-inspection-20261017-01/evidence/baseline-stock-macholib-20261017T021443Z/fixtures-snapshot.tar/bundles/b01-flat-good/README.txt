not a Mach-O file
